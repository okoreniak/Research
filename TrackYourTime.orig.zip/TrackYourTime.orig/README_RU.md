# TrackYourTime 


# [Документация](https://github.com/Allexin/TrackYourTime/wiki/%D0%A0%D1%83%D0%BA%D0%BE%D0%B2%D0%BE%D0%B4%D1%81%D1%82%D0%B2%D0%BE-%D0%BF%D0%BE%D0%BB%D1%8C%D0%B7%D0%BE%D0%B2%D0%B0%D1%82%D0%B5%D0%BB%D1%8F) [[en](https://github.com/Allexin/TrackYourTime/wiki/User-Manual)|[ru](https://github.com/Allexin/TrackYourTime/wiki/%D0%A0%D1%83%D0%BA%D0%BE%D0%B2%D0%BE%D0%B4%D1%81%D1%82%D0%B2%D0%BE-%D0%BF%D0%BE%D0%BB%D1%8C%D0%B7%D0%BE%D0%B2%D0%B0%D1%82%D0%B5%D0%BB%D1%8F)]  

# Загрузка
[Последняя стабильная версия](https://github.com/Allexin/TrackYourTime/releases/tag/0.9.2)

# Roadmap  
https://github.com/Allexin/TrackYourTime/wiki

# Установка

Программа будет работать с той папкой, где была запущена в первый раз. Для того чтобы сменить рабочую папку, надо закрыть программу, перетащить папку в нужное место, запустить, открыть настройки и нажать применить. 

## Windows
Просто распакуйте программу в любую папку и запустите TrackYourTime.exe.

## Max OS X
Распакуйте архив, перетащите TrackYourTime.app в Applications(программы) и запустите.

## Linux
prerequests:

Windows Manager with _NET_ACTIVE_WINDOW property supported

udev input system

application access to /dev/input/by-id/*

Распакуйте архив в любую папку и запустите chesksystem из папки программы.
Следуйте дальнейшим инструкция в checksystem для решения проблем. А потом запустите TrackYourTime.

Иногда автозапуск может не работать в некоторых окружениях. Для этого надо вручную добавить приложение в автозапуск. Не забывайте установить рабочую папку. Программа хоть и будет запущена, но иконки и локализации не будут работать.
