/********************************************************************************
** Form generated from reading UI file 'profileswindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PROFILESWINDOW_H
#define UI_PROFILESWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ProfilesWindow
{
public:
    QWidget *centralwidget;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout;
    QListWidget *listWidgetProfiles;

    void setupUi(QMainWindow *ProfilesWindow)
    {
        if (ProfilesWindow->objectName().isEmpty())
            ProfilesWindow->setObjectName(QString::fromUtf8("ProfilesWindow"));
        ProfilesWindow->setWindowModality(Qt::ApplicationModal);
        ProfilesWindow->resize(800, 600);
        centralwidget = new QWidget(ProfilesWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        horizontalLayout = new QHBoxLayout(centralwidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        listWidgetProfiles = new QListWidget(centralwidget);
        listWidgetProfiles->setObjectName(QString::fromUtf8("listWidgetProfiles"));

        verticalLayout->addWidget(listWidgetProfiles);


        horizontalLayout->addLayout(verticalLayout);

        ProfilesWindow->setCentralWidget(centralwidget);

        retranslateUi(ProfilesWindow);

        QMetaObject::connectSlotsByName(ProfilesWindow);
    } // setupUi

    void retranslateUi(QMainWindow *ProfilesWindow)
    {
        ProfilesWindow->setWindowTitle(QCoreApplication::translate("ProfilesWindow", "Profiles", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ProfilesWindow: public Ui_ProfilesWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PROFILESWINDOW_H
