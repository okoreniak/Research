/****************************************************************************
** Meta object code from reading C++ file 'ctrayicon.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../TrackYourTime/ui/ctrayicon.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'ctrayicon.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_cTrayIcon_t {
    QByteArrayData data[20];
    char stringdata0[244];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_cTrayIcon_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_cTrayIcon_t qt_meta_stringdata_cTrayIcon = {
    {
QT_MOC_LITERAL(0, 0, 9), // "cTrayIcon"
QT_MOC_LITERAL(1, 10, 12), // "showSettings"
QT_MOC_LITERAL(2, 23, 0), // ""
QT_MOC_LITERAL(3, 24, 12), // "showSchedule"
QT_MOC_LITERAL(4, 37, 13), // "showStatistic"
QT_MOC_LITERAL(5, 51, 16), // "showApplications"
QT_MOC_LITERAL(6, 68, 16), // "showNotification"
QT_MOC_LITERAL(7, 85, 9), // "showAbout"
QT_MOC_LITERAL(8, 95, 11), // "rebuildMenu"
QT_MOC_LITERAL(9, 107, 6), // "onTray"
QT_MOC_LITERAL(10, 114, 33), // "QSystemTrayIcon::ActivationRe..."
QT_MOC_LITERAL(11, 148, 6), // "reason"
QT_MOC_LITERAL(12, 155, 9), // "setActive"
QT_MOC_LITERAL(13, 165, 11), // "setInactive"
QT_MOC_LITERAL(14, 177, 8), // "showHint"
QT_MOC_LITERAL(15, 186, 4), // "text"
QT_MOC_LITERAL(16, 191, 16), // "onProfilesChange"
QT_MOC_LITERAL(17, 208, 15), // "onMenuSelection"
QT_MOC_LITERAL(18, 224, 8), // "QAction*"
QT_MOC_LITERAL(19, 233, 10) // "menuAction"

    },
    "cTrayIcon\0showSettings\0\0showSchedule\0"
    "showStatistic\0showApplications\0"
    "showNotification\0showAbout\0rebuildMenu\0"
    "onTray\0QSystemTrayIcon::ActivationReason\0"
    "reason\0setActive\0setInactive\0showHint\0"
    "text\0onProfilesChange\0onMenuSelection\0"
    "QAction*\0menuAction"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_cTrayIcon[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      13,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       6,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   79,    2, 0x06 /* Public */,
       3,    0,   80,    2, 0x06 /* Public */,
       4,    0,   81,    2, 0x06 /* Public */,
       5,    0,   82,    2, 0x06 /* Public */,
       6,    0,   83,    2, 0x06 /* Public */,
       7,    0,   84,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       8,    0,   85,    2, 0x09 /* Protected */,
       9,    1,   86,    2, 0x0a /* Public */,
      12,    0,   89,    2, 0x0a /* Public */,
      13,    0,   90,    2, 0x0a /* Public */,
      14,    1,   91,    2, 0x0a /* Public */,
      16,    0,   94,    2, 0x0a /* Public */,
      17,    1,   95,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 10,   11,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   15,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 18,   19,

       0        // eod
};

void cTrayIcon::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<cTrayIcon *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->showSettings(); break;
        case 1: _t->showSchedule(); break;
        case 2: _t->showStatistic(); break;
        case 3: _t->showApplications(); break;
        case 4: _t->showNotification(); break;
        case 5: _t->showAbout(); break;
        case 6: _t->rebuildMenu(); break;
        case 7: _t->onTray((*reinterpret_cast< QSystemTrayIcon::ActivationReason(*)>(_a[1]))); break;
        case 8: _t->setActive(); break;
        case 9: _t->setInactive(); break;
        case 10: _t->showHint((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 11: _t->onProfilesChange(); break;
        case 12: _t->onMenuSelection((*reinterpret_cast< QAction*(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 12:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QAction* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (cTrayIcon::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&cTrayIcon::showSettings)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (cTrayIcon::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&cTrayIcon::showSchedule)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (cTrayIcon::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&cTrayIcon::showStatistic)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (cTrayIcon::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&cTrayIcon::showApplications)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (cTrayIcon::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&cTrayIcon::showNotification)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (cTrayIcon::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&cTrayIcon::showAbout)) {
                *result = 5;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject cTrayIcon::staticMetaObject = { {
    QMetaObject::SuperData::link<QSystemTrayIcon::staticMetaObject>(),
    qt_meta_stringdata_cTrayIcon.data,
    qt_meta_data_cTrayIcon,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *cTrayIcon::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *cTrayIcon::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_cTrayIcon.stringdata0))
        return static_cast<void*>(this);
    return QSystemTrayIcon::qt_metacast(_clname);
}

int cTrayIcon::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QSystemTrayIcon::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 13)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 13;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 13)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 13;
    }
    return _id;
}

// SIGNAL 0
void cTrayIcon::showSettings()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void cTrayIcon::showSchedule()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void cTrayIcon::showStatistic()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void cTrayIcon::showApplications()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void cTrayIcon::showNotification()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void cTrayIcon::showAbout()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
