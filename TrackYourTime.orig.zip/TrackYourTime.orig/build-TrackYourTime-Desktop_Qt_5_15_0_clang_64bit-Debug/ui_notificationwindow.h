/********************************************************************************
** Form generated from reading UI file 'notificationwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NOTIFICATIONWINDOW_H
#define UI_NOTIFICATIONWINDOW_H

#include <QtCore/QLocale>
#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_NotificationWindow
{
public:
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout;
    QLabel *labelMessage;
    QGroupBox *groupBoxCategory;
    QVBoxLayout *verticalLayout_2;
    QComboBox *comboBoxCategory;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButtonSetForAllProfiles;
    QPushButton *pushButtonSetFoCurrentProfile;

    void setupUi(QMainWindow *NotificationWindow)
    {
        if (NotificationWindow->objectName().isEmpty())
            NotificationWindow->setObjectName(QString::fromUtf8("NotificationWindow"));
        NotificationWindow->resize(800, 192);
        NotificationWindow->setLocale(QLocale(QLocale::Russian, QLocale::Russia));
        centralwidget = new QWidget(NotificationWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        verticalLayout = new QVBoxLayout(centralwidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        labelMessage = new QLabel(centralwidget);
        labelMessage->setObjectName(QString::fromUtf8("labelMessage"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(labelMessage->sizePolicy().hasHeightForWidth());
        labelMessage->setSizePolicy(sizePolicy);
        labelMessage->setWordWrap(true);

        verticalLayout->addWidget(labelMessage);

        groupBoxCategory = new QGroupBox(centralwidget);
        groupBoxCategory->setObjectName(QString::fromUtf8("groupBoxCategory"));
        verticalLayout_2 = new QVBoxLayout(groupBoxCategory);
        verticalLayout_2->setSpacing(0);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        comboBoxCategory = new QComboBox(groupBoxCategory);
        comboBoxCategory->setObjectName(QString::fromUtf8("comboBoxCategory"));
        comboBoxCategory->setEnabled(true);
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(comboBoxCategory->sizePolicy().hasHeightForWidth());
        comboBoxCategory->setSizePolicy(sizePolicy1);

        verticalLayout_2->addWidget(comboBoxCategory);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        pushButtonSetForAllProfiles = new QPushButton(groupBoxCategory);
        pushButtonSetForAllProfiles->setObjectName(QString::fromUtf8("pushButtonSetForAllProfiles"));

        horizontalLayout_2->addWidget(pushButtonSetForAllProfiles);

        pushButtonSetFoCurrentProfile = new QPushButton(groupBoxCategory);
        pushButtonSetFoCurrentProfile->setObjectName(QString::fromUtf8("pushButtonSetFoCurrentProfile"));

        horizontalLayout_2->addWidget(pushButtonSetFoCurrentProfile);


        verticalLayout_2->addLayout(horizontalLayout_2);


        verticalLayout->addWidget(groupBoxCategory);

        NotificationWindow->setCentralWidget(centralwidget);

        retranslateUi(NotificationWindow);

        QMetaObject::connectSlotsByName(NotificationWindow);
    } // setupUi

    void retranslateUi(QMainWindow *NotificationWindow)
    {
        NotificationWindow->setWindowTitle(QCoreApplication::translate("NotificationWindow", "Notification Window", nullptr));
        labelMessage->setText(QString());
        groupBoxCategory->setTitle(QCoreApplication::translate("NotificationWindow", "Category", nullptr));
        pushButtonSetForAllProfiles->setText(QCoreApplication::translate("NotificationWindow", "Set for all profiles.", nullptr));
        pushButtonSetFoCurrentProfile->setText(QCoreApplication::translate("NotificationWindow", "Set for current profile", nullptr));
    } // retranslateUi

};

namespace Ui {
    class NotificationWindow: public Ui_NotificationWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NOTIFICATIONWINDOW_H
