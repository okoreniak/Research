/********************************************************************************
** Form generated from reading UI file 'notification_dummy.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NOTIFICATION_DUMMY_H
#define UI_NOTIFICATION_DUMMY_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_notification_dummy
{
public:
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout;
    QLabel *labelMessage;
    QHBoxLayout *horizontalLayout;
    QLabel *labelCategory;
    QComboBox *comboBoxCategories;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButtonApply;
    QPushButton *pushButtonClose;

    void setupUi(QMainWindow *notification_dummy)
    {
        if (notification_dummy->objectName().isEmpty())
            notification_dummy->setObjectName(QString::fromUtf8("notification_dummy"));
        notification_dummy->resize(800, 187);
        centralwidget = new QWidget(notification_dummy);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        verticalLayout = new QVBoxLayout(centralwidget);
        verticalLayout->setSpacing(0);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        labelMessage = new QLabel(centralwidget);
        labelMessage->setObjectName(QString::fromUtf8("labelMessage"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(labelMessage->sizePolicy().hasHeightForWidth());
        labelMessage->setSizePolicy(sizePolicy);
        labelMessage->setWordWrap(true);

        verticalLayout->addWidget(labelMessage);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(0);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        labelCategory = new QLabel(centralwidget);
        labelCategory->setObjectName(QString::fromUtf8("labelCategory"));

        horizontalLayout->addWidget(labelCategory);

        comboBoxCategories = new QComboBox(centralwidget);
        comboBoxCategories->setObjectName(QString::fromUtf8("comboBoxCategories"));
        comboBoxCategories->setEnabled(false);
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(comboBoxCategories->sizePolicy().hasHeightForWidth());
        comboBoxCategories->setSizePolicy(sizePolicy1);

        horizontalLayout->addWidget(comboBoxCategories);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(0);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        pushButtonApply = new QPushButton(centralwidget);
        pushButtonApply->setObjectName(QString::fromUtf8("pushButtonApply"));

        horizontalLayout_2->addWidget(pushButtonApply);

        pushButtonClose = new QPushButton(centralwidget);
        pushButtonClose->setObjectName(QString::fromUtf8("pushButtonClose"));

        horizontalLayout_2->addWidget(pushButtonClose);


        verticalLayout->addLayout(horizontalLayout_2);

        notification_dummy->setCentralWidget(centralwidget);

        retranslateUi(notification_dummy);

        QMetaObject::connectSlotsByName(notification_dummy);
    } // setupUi

    void retranslateUi(QMainWindow *notification_dummy)
    {
        notification_dummy->setWindowTitle(QCoreApplication::translate("notification_dummy", "Set position and size", nullptr));
        labelMessage->setText(QString());
        labelCategory->setText(QCoreApplication::translate("notification_dummy", "Category:", nullptr));
        pushButtonApply->setText(QCoreApplication::translate("notification_dummy", "Apply", nullptr));
        pushButtonClose->setText(QCoreApplication::translate("notification_dummy", "Close", nullptr));
    } // retranslateUi

};

namespace Ui {
    class notification_dummy: public Ui_notification_dummy {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NOTIFICATION_DUMMY_H
