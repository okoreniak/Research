/****************************************************************************
** Meta object code from reading C++ file 'statisticwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../TrackYourTime/ui/statisticwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'statisticwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_cStatisticDiagramWidget_t {
    QByteArrayData data[1];
    char stringdata0[24];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_cStatisticDiagramWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_cStatisticDiagramWidget_t qt_meta_stringdata_cStatisticDiagramWidget = {
    {
QT_MOC_LITERAL(0, 0, 23) // "cStatisticDiagramWidget"

    },
    "cStatisticDiagramWidget"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_cStatisticDiagramWidget[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void cStatisticDiagramWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject cStatisticDiagramWidget::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_cStatisticDiagramWidget.data,
    qt_meta_data_cStatisticDiagramWidget,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *cStatisticDiagramWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *cStatisticDiagramWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_cStatisticDiagramWidget.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int cStatisticDiagramWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_StatisticWindow_t {
    QByteArrayData data[13];
    char stringdata0[183];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_StatisticWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_StatisticWindow_t qt_meta_stringdata_StatisticWindow = {
    {
QT_MOC_LITERAL(0, 0, 15), // "StatisticWindow"
QT_MOC_LITERAL(1, 16, 16), // "onSetPeriodPress"
QT_MOC_LITERAL(2, 33, 0), // ""
QT_MOC_LITERAL(3, 34, 13), // "onUpdatePress"
QT_MOC_LITERAL(4, 48, 26), // "onExportCategoriesCSVPress"
QT_MOC_LITERAL(5, 75, 28), // "onExportApplicationsCSVPress"
QT_MOC_LITERAL(6, 104, 13), // "showAndUpdate"
QT_MOC_LITERAL(7, 118, 10), // "fastUpdate"
QT_MOC_LITERAL(8, 129, 11), // "application"
QT_MOC_LITERAL(9, 141, 8), // "activity"
QT_MOC_LITERAL(10, 150, 8), // "category"
QT_MOC_LITERAL(11, 159, 12), // "secondsCount"
QT_MOC_LITERAL(12, 172, 10) // "fullUpdate"

    },
    "StatisticWindow\0onSetPeriodPress\0\0"
    "onUpdatePress\0onExportCategoriesCSVPress\0"
    "onExportApplicationsCSVPress\0showAndUpdate\0"
    "fastUpdate\0application\0activity\0"
    "category\0secondsCount\0fullUpdate"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_StatisticWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   44,    2, 0x0a /* Public */,
       3,    0,   45,    2, 0x0a /* Public */,
       4,    0,   46,    2, 0x0a /* Public */,
       5,    0,   47,    2, 0x0a /* Public */,
       6,    0,   48,    2, 0x0a /* Public */,
       7,    5,   49,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Bool,    8,    9,   10,   11,   12,

       0        // eod
};

void StatisticWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<StatisticWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->onSetPeriodPress(); break;
        case 1: _t->onUpdatePress(); break;
        case 2: _t->onExportCategoriesCSVPress(); break;
        case 3: _t->onExportApplicationsCSVPress(); break;
        case 4: _t->showAndUpdate(); break;
        case 5: _t->fastUpdate((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4])),(*reinterpret_cast< bool(*)>(_a[5]))); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject StatisticWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_StatisticWindow.data,
    qt_meta_data_StatisticWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *StatisticWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *StatisticWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_StatisticWindow.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "cStatisticResolver"))
        return static_cast< cStatisticResolver*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int StatisticWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 6)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 6;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
