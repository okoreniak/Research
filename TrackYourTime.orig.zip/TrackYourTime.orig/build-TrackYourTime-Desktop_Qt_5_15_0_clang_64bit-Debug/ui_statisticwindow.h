/********************************************************************************
** Form generated from reading UI file 'statisticwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STATISTICWINDOW_H
#define UI_STATISTICWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTreeWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "statisticwindow.h"

QT_BEGIN_NAMESPACE

class Ui_StatisticWindow
{
public:
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QComboBox *comboBoxPeriod;
    QPushButton *pushButtonSetPeriod;
    QLabel *label_2;
    QDateEdit *dateEditFrom;
    QLabel *label;
    QDateEdit *dateEditTo;
    QPushButton *pushButtonUpdate;
    QSpacerItem *horizontalSpacer;
    QFrame *line;
    QHBoxLayout *horizontalLayout_3;
    QPushButton *pushButtonExportCategoriesCSV;
    QPushButton *pushButtonExportApplicationsCSV;
    QHBoxLayout *horizontalLayout_2;
    cStatisticDiagramWidget *widgetDiagram;
    QVBoxLayout *verticalLayout_3;
    QTreeWidget *treeWidgetApplications;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_4;
    QLabel *labelTotalTime;

    void setupUi(QMainWindow *StatisticWindow)
    {
        if (StatisticWindow->objectName().isEmpty())
            StatisticWindow->setObjectName(QString::fromUtf8("StatisticWindow"));
        StatisticWindow->resize(776, 550);
        centralwidget = new QWidget(StatisticWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        verticalLayout_2 = new QVBoxLayout(centralwidget);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        comboBoxPeriod = new QComboBox(centralwidget);
        comboBoxPeriod->addItem(QString());
        comboBoxPeriod->addItem(QString());
        comboBoxPeriod->addItem(QString());
        comboBoxPeriod->addItem(QString());
        comboBoxPeriod->setObjectName(QString::fromUtf8("comboBoxPeriod"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(comboBoxPeriod->sizePolicy().hasHeightForWidth());
        comboBoxPeriod->setSizePolicy(sizePolicy);

        horizontalLayout->addWidget(comboBoxPeriod);

        pushButtonSetPeriod = new QPushButton(centralwidget);
        pushButtonSetPeriod->setObjectName(QString::fromUtf8("pushButtonSetPeriod"));
        sizePolicy.setHeightForWidth(pushButtonSetPeriod->sizePolicy().hasHeightForWidth());
        pushButtonSetPeriod->setSizePolicy(sizePolicy);

        horizontalLayout->addWidget(pushButtonSetPeriod);

        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout->addWidget(label_2);

        dateEditFrom = new QDateEdit(centralwidget);
        dateEditFrom->setObjectName(QString::fromUtf8("dateEditFrom"));
        sizePolicy.setHeightForWidth(dateEditFrom->sizePolicy().hasHeightForWidth());
        dateEditFrom->setSizePolicy(sizePolicy);

        horizontalLayout->addWidget(dateEditFrom);

        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        dateEditTo = new QDateEdit(centralwidget);
        dateEditTo->setObjectName(QString::fromUtf8("dateEditTo"));
        sizePolicy.setHeightForWidth(dateEditTo->sizePolicy().hasHeightForWidth());
        dateEditTo->setSizePolicy(sizePolicy);

        horizontalLayout->addWidget(dateEditTo);

        pushButtonUpdate = new QPushButton(centralwidget);
        pushButtonUpdate->setObjectName(QString::fromUtf8("pushButtonUpdate"));
        sizePolicy.setHeightForWidth(pushButtonUpdate->sizePolicy().hasHeightForWidth());
        pushButtonUpdate->setSizePolicy(sizePolicy);

        horizontalLayout->addWidget(pushButtonUpdate);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);


        verticalLayout->addLayout(horizontalLayout);

        line = new QFrame(centralwidget);
        line->setObjectName(QString::fromUtf8("line"));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        pushButtonExportCategoriesCSV = new QPushButton(centralwidget);
        pushButtonExportCategoriesCSV->setObjectName(QString::fromUtf8("pushButtonExportCategoriesCSV"));
        sizePolicy.setHeightForWidth(pushButtonExportCategoriesCSV->sizePolicy().hasHeightForWidth());
        pushButtonExportCategoriesCSV->setSizePolicy(sizePolicy);

        horizontalLayout_3->addWidget(pushButtonExportCategoriesCSV);

        pushButtonExportApplicationsCSV = new QPushButton(centralwidget);
        pushButtonExportApplicationsCSV->setObjectName(QString::fromUtf8("pushButtonExportApplicationsCSV"));
        sizePolicy.setHeightForWidth(pushButtonExportApplicationsCSV->sizePolicy().hasHeightForWidth());
        pushButtonExportApplicationsCSV->setSizePolicy(sizePolicy);

        horizontalLayout_3->addWidget(pushButtonExportApplicationsCSV);


        verticalLayout->addLayout(horizontalLayout_3);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setSizeConstraint(QLayout::SetFixedSize);
        widgetDiagram = new cStatisticDiagramWidget(centralwidget);
        widgetDiagram->setObjectName(QString::fromUtf8("widgetDiagram"));
        QSizePolicy sizePolicy1(QSizePolicy::MinimumExpanding, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(widgetDiagram->sizePolicy().hasHeightForWidth());
        widgetDiagram->setSizePolicy(sizePolicy1);

        horizontalLayout_2->addWidget(widgetDiagram);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, -1, -1, -1);
        treeWidgetApplications = new QTreeWidget(centralwidget);
        QTreeWidgetItem *__qtreewidgetitem = new QTreeWidgetItem();
        __qtreewidgetitem->setText(0, QString::fromUtf8("Applications"));
        treeWidgetApplications->setHeaderItem(__qtreewidgetitem);
        treeWidgetApplications->setObjectName(QString::fromUtf8("treeWidgetApplications"));
        QSizePolicy sizePolicy2(QSizePolicy::MinimumExpanding, QSizePolicy::Expanding);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(treeWidgetApplications->sizePolicy().hasHeightForWidth());
        treeWidgetApplications->setSizePolicy(sizePolicy2);
        treeWidgetApplications->setColumnCount(3);
        treeWidgetApplications->header()->setDefaultSectionSize(150);
        treeWidgetApplications->header()->setHighlightSections(true);
        treeWidgetApplications->header()->setProperty("showSortIndicator", QVariant(false));

        verticalLayout_3->addWidget(treeWidgetApplications);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(-1, 0, -1, -1);
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout_5->addWidget(label_4);

        labelTotalTime = new QLabel(centralwidget);
        labelTotalTime->setObjectName(QString::fromUtf8("labelTotalTime"));

        horizontalLayout_5->addWidget(labelTotalTime);


        verticalLayout_3->addLayout(horizontalLayout_5);


        horizontalLayout_2->addLayout(verticalLayout_3);


        verticalLayout->addLayout(horizontalLayout_2);


        verticalLayout_2->addLayout(verticalLayout);

        StatisticWindow->setCentralWidget(centralwidget);

        retranslateUi(StatisticWindow);

        comboBoxPeriod->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(StatisticWindow);
    } // setupUi

    void retranslateUi(QMainWindow *StatisticWindow)
    {
        StatisticWindow->setWindowTitle(QCoreApplication::translate("StatisticWindow", "Statistic", nullptr));
        comboBoxPeriod->setItemText(0, QCoreApplication::translate("StatisticWindow", "Today", nullptr));
        comboBoxPeriod->setItemText(1, QCoreApplication::translate("StatisticWindow", "This week", nullptr));
        comboBoxPeriod->setItemText(2, QCoreApplication::translate("StatisticWindow", "This month", nullptr));
        comboBoxPeriod->setItemText(3, QCoreApplication::translate("StatisticWindow", "This year", nullptr));

        pushButtonSetPeriod->setText(QCoreApplication::translate("StatisticWindow", ">>", nullptr));
        label_2->setText(QCoreApplication::translate("StatisticWindow", "From", nullptr));
        label->setText(QCoreApplication::translate("StatisticWindow", "to", nullptr));
        pushButtonUpdate->setText(QCoreApplication::translate("StatisticWindow", "Update", nullptr));
        pushButtonExportCategoriesCSV->setText(QCoreApplication::translate("StatisticWindow", "Export categories to CSV...", nullptr));
        pushButtonExportApplicationsCSV->setText(QCoreApplication::translate("StatisticWindow", "Export applications to CSV...", nullptr));
        QTreeWidgetItem *___qtreewidgetitem = treeWidgetApplications->headerItem();
        ___qtreewidgetitem->setText(2, QCoreApplication::translate("StatisticWindow", "Relative time", nullptr));
        ___qtreewidgetitem->setText(1, QCoreApplication::translate("StatisticWindow", "Absolute time", nullptr));
        label_4->setText(QCoreApplication::translate("StatisticWindow", "Total Time:", nullptr));
        labelTotalTime->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class StatisticWindow: public Ui_StatisticWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STATISTICWINDOW_H
