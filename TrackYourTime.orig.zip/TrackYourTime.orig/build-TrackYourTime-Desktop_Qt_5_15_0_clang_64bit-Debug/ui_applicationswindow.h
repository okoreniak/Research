/********************************************************************************
** Form generated from reading UI file 'applicationswindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_APPLICATIONSWINDOW_H
#define UI_APPLICATIONSWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "applicationswindow.h"

QT_BEGIN_NAMESPACE

class Ui_ApplicationsWindow
{
public:
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QHBoxLayout *horizontalLayout;
    QComboBox *comboBoxProfiles;
    QPushButton *pushButtonEditProfiles;
    QLabel *label_2;
    cApplicationsTreeWidget *treeWidgetApplications;
    QCheckBox *checkBoxShowHidden;
    QLabel *label_3;

    void setupUi(QMainWindow *ApplicationsWindow)
    {
        if (ApplicationsWindow->objectName().isEmpty())
            ApplicationsWindow->setObjectName(QString::fromUtf8("ApplicationsWindow"));
        ApplicationsWindow->resize(718, 564);
        centralwidget = new QWidget(ApplicationsWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        QSizePolicy sizePolicy(QSizePolicy::Maximum, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(centralwidget->sizePolicy().hasHeightForWidth());
        centralwidget->setSizePolicy(sizePolicy);
        verticalLayout_2 = new QVBoxLayout(centralwidget);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setSizeConstraint(QLayout::SetDefaultConstraint);
        verticalLayout->setContentsMargins(10, 10, 10, 10);
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));

        verticalLayout->addWidget(label);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        comboBoxProfiles = new QComboBox(centralwidget);
        comboBoxProfiles->setObjectName(QString::fromUtf8("comboBoxProfiles"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(comboBoxProfiles->sizePolicy().hasHeightForWidth());
        comboBoxProfiles->setSizePolicy(sizePolicy1);

        horizontalLayout->addWidget(comboBoxProfiles);

        pushButtonEditProfiles = new QPushButton(centralwidget);
        pushButtonEditProfiles->setObjectName(QString::fromUtf8("pushButtonEditProfiles"));
        QSizePolicy sizePolicy2(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(pushButtonEditProfiles->sizePolicy().hasHeightForWidth());
        pushButtonEditProfiles->setSizePolicy(sizePolicy2);
        pushButtonEditProfiles->setMaximumSize(QSize(16777215, 16777215));

        horizontalLayout->addWidget(pushButtonEditProfiles);


        verticalLayout->addLayout(horizontalLayout);

        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        verticalLayout->addWidget(label_2);

        treeWidgetApplications = new cApplicationsTreeWidget(centralwidget);
        QTreeWidgetItem *__qtreewidgetitem = new QTreeWidgetItem();
        __qtreewidgetitem->setText(0, QString::fromUtf8("1"));
        treeWidgetApplications->setHeaderItem(__qtreewidgetitem);
        treeWidgetApplications->setObjectName(QString::fromUtf8("treeWidgetApplications"));
        treeWidgetApplications->setSelectionMode(QAbstractItemView::ExtendedSelection);
        treeWidgetApplications->header()->setVisible(false);

        verticalLayout->addWidget(treeWidgetApplications);

        checkBoxShowHidden = new QCheckBox(centralwidget);
        checkBoxShowHidden->setObjectName(QString::fromUtf8("checkBoxShowHidden"));

        verticalLayout->addWidget(checkBoxShowHidden);

        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        verticalLayout->addWidget(label_3);


        verticalLayout_2->addLayout(verticalLayout);

        ApplicationsWindow->setCentralWidget(centralwidget);

        retranslateUi(ApplicationsWindow);

        QMetaObject::connectSlotsByName(ApplicationsWindow);
    } // setupUi

    void retranslateUi(QMainWindow *ApplicationsWindow)
    {
        ApplicationsWindow->setWindowTitle(QCoreApplication::translate("ApplicationsWindow", "Applications", nullptr));
        label->setText(QCoreApplication::translate("ApplicationsWindow", "Profiles", nullptr));
        pushButtonEditProfiles->setText(QCoreApplication::translate("ApplicationsWindow", "Edit...", nullptr));
        label_2->setText(QCoreApplication::translate("ApplicationsWindow", "Categories and Applications:", nullptr));
        checkBoxShowHidden->setText(QCoreApplication::translate("ApplicationsWindow", "Show hidden objects", nullptr));
        label_3->setText(QCoreApplication::translate("ApplicationsWindow", "<html><head/><body><p>Drag &amp; press &quot;Control&quot; before Drop to move application into a same category in all profiles.</p><p>Drag &amp; Drop application without &quot;Contol&quot; to move application into a category only in current profile.</p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ApplicationsWindow: public Ui_ApplicationsWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_APPLICATIONSWINDOW_H
