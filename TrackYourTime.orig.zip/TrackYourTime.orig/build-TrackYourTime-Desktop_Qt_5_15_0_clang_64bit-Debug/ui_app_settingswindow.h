/********************************************************************************
** Form generated from reading UI file 'app_settingswindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_APP_SETTINGSWINDOW_H
#define UI_APP_SETTINGSWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_App_SettingsWindow
{
public:
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLabel *labelApplication;
    QSpacerItem *horizontalSpacer;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_2;
    QComboBox *comboBoxTrackingType;
    QLabel *label_4;
    QLabel *labelAdditionalInfo;
    QVBoxLayout *verticalLayout_3;
    QCheckBox *checkBoxCustomScript;
    QPlainTextEdit *plainTextEditScript;
    QPushButton *pushButtonApply;
    QLabel *label_5;
    QPushButton *pushButtonStartDebug;
    QLabel *label_6;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_8;
    QLabel *labelDebugApp;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_9;
    QLabel *labelDebugTitle;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_3;
    QLabel *labelDebugTrackingResult;
    QLabel *label_7;
    QLabel *labelDebugResult;

    void setupUi(QMainWindow *App_SettingsWindow)
    {
        if (App_SettingsWindow->objectName().isEmpty())
            App_SettingsWindow->setObjectName(QString::fromUtf8("App_SettingsWindow"));
        App_SettingsWindow->resize(510, 546);
        centralwidget = new QWidget(App_SettingsWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        QSizePolicy sizePolicy(QSizePolicy::Maximum, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(centralwidget->sizePolicy().hasHeightForWidth());
        centralwidget->setSizePolicy(sizePolicy);
        verticalLayout_2 = new QVBoxLayout(centralwidget);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setSizeConstraint(QLayout::SetMinimumSize);
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        labelApplication = new QLabel(centralwidget);
        labelApplication->setObjectName(QString::fromUtf8("labelApplication"));

        horizontalLayout->addWidget(labelApplication);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_3->addWidget(label_2);

        comboBoxTrackingType = new QComboBox(centralwidget);
        comboBoxTrackingType->addItem(QString());
        comboBoxTrackingType->addItem(QString());
        comboBoxTrackingType->addItem(QString());
        comboBoxTrackingType->setObjectName(QString::fromUtf8("comboBoxTrackingType"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(comboBoxTrackingType->sizePolicy().hasHeightForWidth());
        comboBoxTrackingType->setSizePolicy(sizePolicy1);
        comboBoxTrackingType->setMinimumSize(QSize(200, 0));

        horizontalLayout_3->addWidget(comboBoxTrackingType);


        verticalLayout->addLayout(horizontalLayout_3);

        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        verticalLayout->addWidget(label_4);

        labelAdditionalInfo = new QLabel(centralwidget);
        labelAdditionalInfo->setObjectName(QString::fromUtf8("labelAdditionalInfo"));
        labelAdditionalInfo->setOpenExternalLinks(true);

        verticalLayout->addWidget(labelAdditionalInfo);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        checkBoxCustomScript = new QCheckBox(centralwidget);
        checkBoxCustomScript->setObjectName(QString::fromUtf8("checkBoxCustomScript"));

        verticalLayout_3->addWidget(checkBoxCustomScript);

        plainTextEditScript = new QPlainTextEdit(centralwidget);
        plainTextEditScript->setObjectName(QString::fromUtf8("plainTextEditScript"));

        verticalLayout_3->addWidget(plainTextEditScript);

        pushButtonApply = new QPushButton(centralwidget);
        pushButtonApply->setObjectName(QString::fromUtf8("pushButtonApply"));
        QSizePolicy sizePolicy2(QSizePolicy::Minimum, QSizePolicy::Preferred);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(pushButtonApply->sizePolicy().hasHeightForWidth());
        pushButtonApply->setSizePolicy(sizePolicy2);

        verticalLayout_3->addWidget(pushButtonApply);

        label_5 = new QLabel(centralwidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        verticalLayout_3->addWidget(label_5);

        pushButtonStartDebug = new QPushButton(centralwidget);
        pushButtonStartDebug->setObjectName(QString::fromUtf8("pushButtonStartDebug"));
        sizePolicy2.setHeightForWidth(pushButtonStartDebug->sizePolicy().hasHeightForWidth());
        pushButtonStartDebug->setSizePolicy(sizePolicy2);

        verticalLayout_3->addWidget(pushButtonStartDebug);

        label_6 = new QLabel(centralwidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        verticalLayout_3->addWidget(label_6);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_8 = new QLabel(centralwidget);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        horizontalLayout_2->addWidget(label_8);

        labelDebugApp = new QLabel(centralwidget);
        labelDebugApp->setObjectName(QString::fromUtf8("labelDebugApp"));

        horizontalLayout_2->addWidget(labelDebugApp);


        verticalLayout_3->addLayout(horizontalLayout_2);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        label_9 = new QLabel(centralwidget);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        horizontalLayout_4->addWidget(label_9);

        labelDebugTitle = new QLabel(centralwidget);
        labelDebugTitle->setObjectName(QString::fromUtf8("labelDebugTitle"));

        horizontalLayout_4->addWidget(labelDebugTitle);


        verticalLayout_3->addLayout(horizontalLayout_4);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(-1, -1, -1, 0);
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_5->addWidget(label_3);

        labelDebugTrackingResult = new QLabel(centralwidget);
        labelDebugTrackingResult->setObjectName(QString::fromUtf8("labelDebugTrackingResult"));

        horizontalLayout_5->addWidget(labelDebugTrackingResult);


        verticalLayout_3->addLayout(horizontalLayout_5);


        verticalLayout->addLayout(verticalLayout_3);

        label_7 = new QLabel(centralwidget);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        verticalLayout->addWidget(label_7);

        labelDebugResult = new QLabel(centralwidget);
        labelDebugResult->setObjectName(QString::fromUtf8("labelDebugResult"));

        verticalLayout->addWidget(labelDebugResult);


        verticalLayout_2->addLayout(verticalLayout);

        App_SettingsWindow->setCentralWidget(centralwidget);

        retranslateUi(App_SettingsWindow);

        QMetaObject::connectSlotsByName(App_SettingsWindow);
    } // setupUi

    void retranslateUi(QMainWindow *App_SettingsWindow)
    {
        App_SettingsWindow->setWindowTitle(QCoreApplication::translate("App_SettingsWindow", "Application settings", nullptr));
        label->setText(QCoreApplication::translate("App_SettingsWindow", "Application:", nullptr));
        labelApplication->setText(QString());
        label_2->setText(QCoreApplication::translate("App_SettingsWindow", "Tracking:", nullptr));
        comboBoxTrackingType->setItemText(0, QCoreApplication::translate("App_SettingsWindow", "By application name", nullptr));
        comboBoxTrackingType->setItemText(1, QCoreApplication::translate("App_SettingsWindow", "By external tracker", nullptr));
        comboBoxTrackingType->setItemText(2, QCoreApplication::translate("App_SettingsWindow", "By predefined script", nullptr));

        label_4->setText(QCoreApplication::translate("App_SettingsWindow", "Warning: do not forget to install external tracker if availble!", nullptr));
        labelAdditionalInfo->setText(QString());
#if QT_CONFIG(tooltip)
        checkBoxCustomScript->setToolTip(QCoreApplication::translate("App_SettingsWindow", "<html><head/><body><p>Process custom script as last step of tracking</p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        checkBoxCustomScript->setText(QCoreApplication::translate("App_SettingsWindow", "Use custom script", nullptr));
        pushButtonApply->setText(QCoreApplication::translate("App_SettingsWindow", "Apply", nullptr));
        label_5->setText(QCoreApplication::translate("App_SettingsWindow", "Developer tools:", nullptr));
        pushButtonStartDebug->setText(QCoreApplication::translate("App_SettingsWindow", "Start debuging current script", nullptr));
        label_6->setText(QCoreApplication::translate("App_SettingsWindow", "Debug data:", nullptr));
        label_8->setText(QCoreApplication::translate("App_SettingsWindow", "Application Name or Class:", nullptr));
        labelDebugApp->setText(QString());
        label_9->setText(QCoreApplication::translate("App_SettingsWindow", "Application title:", nullptr));
        labelDebugTitle->setText(QString());
        label_3->setText(QCoreApplication::translate("App_SettingsWindow", "Tracking result:", nullptr));
        labelDebugTrackingResult->setText(QString());
        label_7->setText(QCoreApplication::translate("App_SettingsWindow", "Script result:", nullptr));
        labelDebugResult->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class App_SettingsWindow: public Ui_App_SettingsWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_APP_SETTINGSWINDOW_H
