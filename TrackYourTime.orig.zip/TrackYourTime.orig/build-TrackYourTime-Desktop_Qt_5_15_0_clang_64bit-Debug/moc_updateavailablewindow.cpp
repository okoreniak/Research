/****************************************************************************
** Meta object code from reading C++ file 'updateavailablewindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../TrackYourTime/ui/updateavailablewindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'updateavailablewindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_UpdateAvailableWindow_t {
    QByteArrayData data[9];
    char stringdata0[154];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_UpdateAvailableWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_UpdateAvailableWindow_t qt_meta_stringdata_UpdateAvailableWindow = {
    {
QT_MOC_LITERAL(0, 0, 21), // "UpdateAvailableWindow"
QT_MOC_LITERAL(1, 22, 12), // "ignoreUpdate"
QT_MOC_LITERAL(2, 35, 0), // ""
QT_MOC_LITERAL(3, 36, 21), // "processButtonDownload"
QT_MOC_LITERAL(4, 58, 22), // "processButtonChangelog"
QT_MOC_LITERAL(5, 81, 24), // "processButtonRemindLater"
QT_MOC_LITERAL(6, 106, 25), // "processButtonIgnoreUpdate"
QT_MOC_LITERAL(7, 132, 10), // "showUpdate"
QT_MOC_LITERAL(8, 143, 10) // "newVersion"

    },
    "UpdateAvailableWindow\0ignoreUpdate\0\0"
    "processButtonDownload\0processButtonChangelog\0"
    "processButtonRemindLater\0"
    "processButtonIgnoreUpdate\0showUpdate\0"
    "newVersion"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_UpdateAvailableWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   44,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       3,    0,   45,    2, 0x09 /* Protected */,
       4,    0,   46,    2, 0x09 /* Protected */,
       5,    0,   47,    2, 0x09 /* Protected */,
       6,    0,   48,    2, 0x09 /* Protected */,
       7,    1,   49,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    8,

       0        // eod
};

void UpdateAvailableWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<UpdateAvailableWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->ignoreUpdate(); break;
        case 1: _t->processButtonDownload(); break;
        case 2: _t->processButtonChangelog(); break;
        case 3: _t->processButtonRemindLater(); break;
        case 4: _t->processButtonIgnoreUpdate(); break;
        case 5: _t->showUpdate((*reinterpret_cast< QString(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (UpdateAvailableWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&UpdateAvailableWindow::ignoreUpdate)) {
                *result = 0;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject UpdateAvailableWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_UpdateAvailableWindow.data,
    qt_meta_data_UpdateAvailableWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *UpdateAvailableWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *UpdateAvailableWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_UpdateAvailableWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int UpdateAvailableWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 6)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 6;
    }
    return _id;
}

// SIGNAL 0
void UpdateAvailableWindow::ignoreUpdate()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
