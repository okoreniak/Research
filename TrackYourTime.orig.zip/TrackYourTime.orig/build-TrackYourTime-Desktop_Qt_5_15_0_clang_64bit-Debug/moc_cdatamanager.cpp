/****************************************************************************
** Meta object code from reading C++ file 'cdatamanager.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../TrackYourTime/data/cdatamanager.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'cdatamanager.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_cDataManager_t {
    QByteArrayData data[22];
    char stringdata0[263];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_cDataManager_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_cDataManager_t qt_meta_stringdata_cDataManager = {
    {
QT_MOC_LITERAL(0, 0, 12), // "cDataManager"
QT_MOC_LITERAL(1, 13, 12), // "trayShowHint"
QT_MOC_LITERAL(2, 26, 0), // ""
QT_MOC_LITERAL(3, 27, 4), // "text"
QT_MOC_LITERAL(4, 32, 10), // "trayActive"
QT_MOC_LITERAL(5, 43, 9), // "traySleep"
QT_MOC_LITERAL(6, 53, 15), // "profilesChanged"
QT_MOC_LITERAL(7, 69, 19), // "applicationsChanged"
QT_MOC_LITERAL(8, 89, 17), // "debugScriptResult"
QT_MOC_LITERAL(9, 107, 6), // "result"
QT_MOC_LITERAL(10, 114, 8), // "sSysInfo"
QT_MOC_LITERAL(11, 123, 4), // "data"
QT_MOC_LITERAL(12, 128, 14), // "trackingResult"
QT_MOC_LITERAL(13, 143, 16), // "showNotification"
QT_MOC_LITERAL(14, 160, 19), // "statisticFastUpdate"
QT_MOC_LITERAL(15, 180, 11), // "application"
QT_MOC_LITERAL(16, 192, 8), // "activity"
QT_MOC_LITERAL(17, 201, 8), // "category"
QT_MOC_LITERAL(18, 210, 12), // "secondsCount"
QT_MOC_LITERAL(19, 223, 10), // "fullUpdate"
QT_MOC_LITERAL(20, 234, 7), // "process"
QT_MOC_LITERAL(21, 242, 20) // "onPreferencesChanged"

    },
    "cDataManager\0trayShowHint\0\0text\0"
    "trayActive\0traySleep\0profilesChanged\0"
    "applicationsChanged\0debugScriptResult\0"
    "result\0sSysInfo\0data\0trackingResult\0"
    "showNotification\0statisticFastUpdate\0"
    "application\0activity\0category\0"
    "secondsCount\0fullUpdate\0process\0"
    "onPreferencesChanged"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_cDataManager[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       8,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   64,    2, 0x06 /* Public */,
       4,    0,   67,    2, 0x06 /* Public */,
       5,    0,   68,    2, 0x06 /* Public */,
       6,    0,   69,    2, 0x06 /* Public */,
       7,    0,   70,    2, 0x06 /* Public */,
       8,    3,   71,    2, 0x06 /* Public */,
      13,    0,   78,    2, 0x06 /* Public */,
      14,    5,   79,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      20,    0,   90,    2, 0x0a /* Public */,
      21,    0,   91,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, 0x80000000 | 10, QMetaType::QString,    9,   11,   12,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Bool,   15,   16,   17,   18,   19,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void cDataManager::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<cDataManager *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->trayShowHint((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 1: _t->trayActive(); break;
        case 2: _t->traySleep(); break;
        case 3: _t->profilesChanged(); break;
        case 4: _t->applicationsChanged(); break;
        case 5: _t->debugScriptResult((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< const sSysInfo(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 6: _t->showNotification(); break;
        case 7: _t->statisticFastUpdate((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4])),(*reinterpret_cast< bool(*)>(_a[5]))); break;
        case 8: _t->process(); break;
        case 9: _t->onPreferencesChanged(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (cDataManager::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&cDataManager::trayShowHint)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (cDataManager::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&cDataManager::trayActive)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (cDataManager::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&cDataManager::traySleep)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (cDataManager::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&cDataManager::profilesChanged)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (cDataManager::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&cDataManager::applicationsChanged)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (cDataManager::*)(QString , const sSysInfo & , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&cDataManager::debugScriptResult)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (cDataManager::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&cDataManager::showNotification)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (cDataManager::*)(int , int , int , int , bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&cDataManager::statisticFastUpdate)) {
                *result = 7;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject cDataManager::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_cDataManager.data,
    qt_meta_data_cDataManager,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *cDataManager::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *cDataManager::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_cDataManager.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int cDataManager::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 10)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 10;
    }
    return _id;
}

// SIGNAL 0
void cDataManager::trayShowHint(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void cDataManager::trayActive()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void cDataManager::traySleep()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void cDataManager::profilesChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void cDataManager::applicationsChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void cDataManager::debugScriptResult(QString _t1, const sSysInfo & _t2, QString _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void cDataManager::showNotification()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}

// SIGNAL 7
void cDataManager::statisticFastUpdate(int _t1, int _t2, int _t3, int _t4, bool _t5)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t5))) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
