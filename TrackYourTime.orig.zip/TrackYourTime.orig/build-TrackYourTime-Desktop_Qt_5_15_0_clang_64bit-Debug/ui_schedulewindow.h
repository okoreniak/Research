/********************************************************************************
** Form generated from reading UI file 'schedulewindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SCHEDULEWINDOW_H
#define UI_SCHEDULEWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTreeWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ScheduleWindow
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QTreeWidget *treeWidgetSchedule;
    QGroupBox *groupBox;
    QVBoxLayout *verticalLayout_3;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_3;
    QComboBox *comboBoxAction;
    QHBoxLayout *horizontalLayout;
    QLabel *label_2;
    QComboBox *comboBoxProfiles;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_4;
    QLineEdit *lineEditCondition;
    QLabel *label_5;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_6;
    QLabel *labelCurrentDateTime;
    QHBoxLayout *horizontalLayout_5;
    QPushButton *pushButtonAdd;
    QPushButton *pushButtonDelete;

    void setupUi(QMainWindow *ScheduleWindow)
    {
        if (ScheduleWindow->objectName().isEmpty())
            ScheduleWindow->setObjectName(QString::fromUtf8("ScheduleWindow"));
        ScheduleWindow->resize(800, 566);
        centralwidget = new QWidget(ScheduleWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        gridLayout = new QGridLayout(centralwidget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));

        verticalLayout->addWidget(label);

        treeWidgetSchedule = new QTreeWidget(centralwidget);
        QTreeWidgetItem *__qtreewidgetitem = new QTreeWidgetItem();
        __qtreewidgetitem->setText(2, QString::fromUtf8("Condition"));
        __qtreewidgetitem->setText(1, QString::fromUtf8("Params"));
        __qtreewidgetitem->setText(0, QString::fromUtf8("Action"));
        treeWidgetSchedule->setHeaderItem(__qtreewidgetitem);
        treeWidgetSchedule->setObjectName(QString::fromUtf8("treeWidgetSchedule"));
        treeWidgetSchedule->setColumnCount(3);
        treeWidgetSchedule->header()->setVisible(false);
        treeWidgetSchedule->header()->setDefaultSectionSize(200);
        treeWidgetSchedule->header()->setHighlightSections(true);

        verticalLayout->addWidget(treeWidgetSchedule);

        groupBox = new QGroupBox(centralwidget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setMinimumSize(QSize(0, 200));
        verticalLayout_3 = new QVBoxLayout(groupBox);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_3 = new QLabel(groupBox);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_2->addWidget(label_3);

        comboBoxAction = new QComboBox(groupBox);
        comboBoxAction->setObjectName(QString::fromUtf8("comboBoxAction"));

        horizontalLayout_2->addWidget(comboBoxAction);


        verticalLayout_2->addLayout(horizontalLayout_2);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout->addWidget(label_2);

        comboBoxProfiles = new QComboBox(groupBox);
        comboBoxProfiles->setObjectName(QString::fromUtf8("comboBoxProfiles"));

        horizontalLayout->addWidget(comboBoxProfiles);


        verticalLayout_2->addLayout(horizontalLayout);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        label_4 = new QLabel(groupBox);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout_4->addWidget(label_4);

        lineEditCondition = new QLineEdit(groupBox);
        lineEditCondition->setObjectName(QString::fromUtf8("lineEditCondition"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(lineEditCondition->sizePolicy().hasHeightForWidth());
        lineEditCondition->setSizePolicy(sizePolicy);

        horizontalLayout_4->addWidget(lineEditCondition);


        verticalLayout_2->addLayout(horizontalLayout_4);

        label_5 = new QLabel(groupBox);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setOpenExternalLinks(true);

        verticalLayout_2->addWidget(label_5);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_6 = new QLabel(groupBox);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        horizontalLayout_3->addWidget(label_6);

        labelCurrentDateTime = new QLabel(groupBox);
        labelCurrentDateTime->setObjectName(QString::fromUtf8("labelCurrentDateTime"));

        horizontalLayout_3->addWidget(labelCurrentDateTime);


        verticalLayout_2->addLayout(horizontalLayout_3);


        verticalLayout_3->addLayout(verticalLayout_2);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        pushButtonAdd = new QPushButton(groupBox);
        pushButtonAdd->setObjectName(QString::fromUtf8("pushButtonAdd"));
        QSizePolicy sizePolicy1(QSizePolicy::Minimum, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(pushButtonAdd->sizePolicy().hasHeightForWidth());
        pushButtonAdd->setSizePolicy(sizePolicy1);

        horizontalLayout_5->addWidget(pushButtonAdd);

        pushButtonDelete = new QPushButton(groupBox);
        pushButtonDelete->setObjectName(QString::fromUtf8("pushButtonDelete"));
        sizePolicy1.setHeightForWidth(pushButtonDelete->sizePolicy().hasHeightForWidth());
        pushButtonDelete->setSizePolicy(sizePolicy1);

        horizontalLayout_5->addWidget(pushButtonDelete);


        verticalLayout_3->addLayout(horizontalLayout_5);


        verticalLayout->addWidget(groupBox);


        gridLayout->addLayout(verticalLayout, 0, 0, 1, 1);

        ScheduleWindow->setCentralWidget(centralwidget);

        retranslateUi(ScheduleWindow);

        QMetaObject::connectSlotsByName(ScheduleWindow);
    } // setupUi

    void retranslateUi(QMainWindow *ScheduleWindow)
    {
        ScheduleWindow->setWindowTitle(QCoreApplication::translate("ScheduleWindow", "Schedule", nullptr));
        label->setText(QCoreApplication::translate("ScheduleWindow", "Schedule", nullptr));
        groupBox->setTitle(QCoreApplication::translate("ScheduleWindow", "New schedule record:", nullptr));
        label_3->setText(QCoreApplication::translate("ScheduleWindow", "Action", nullptr));
        label_2->setText(QCoreApplication::translate("ScheduleWindow", "Profile", nullptr));
        label_4->setText(QCoreApplication::translate("ScheduleWindow", "Condition(e.g .*15:37 or .*Mon.*12:40 )", nullptr));
        label_5->setText(QCoreApplication::translate("ScheduleWindow", "<html><head/><body><p>Regular Expressions syntax: <a href=\"https://doc.qt.io/qt-4.8/qregexp.html#introduction\"><span style=\" text-decoration: underline; color:#0000ff;\">https://doc.qt.io/qt-4.8/qregexp.html#introduction</span></a></p></body></html>", nullptr));
        label_6->setText(QCoreApplication::translate("ScheduleWindow", "Current date and time:", nullptr));
        labelCurrentDateTime->setText(QString());
        pushButtonAdd->setText(QCoreApplication::translate("ScheduleWindow", "Add new record", nullptr));
        pushButtonDelete->setText(QCoreApplication::translate("ScheduleWindow", "Delete selected record", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ScheduleWindow: public Ui_ScheduleWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SCHEDULEWINDOW_H
