/********************************************************************************
** Form generated from reading UI file 'settingswindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SETTINGSWINDOW_H
#define UI_SETTINGSWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SettingsWindow
{
public:
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_4;
    QComboBox *comboBoxLanguage;
    QHBoxLayout *horizontalLayout_6;
    QLabel *label_2;
    QSpinBox *spinBoxIdleDelay;
    QHBoxLayout *horizontalLayout_7;
    QLabel *label_3;
    QSpinBox *spinBoxAutosaveDelay;
    QGroupBox *groupBox_3;
    QVBoxLayout *verticalLayout_5;
    QGroupBox *groupBox_4;
    QVBoxLayout *verticalLayout_6;
    QHBoxLayout *horizontalLayout;
    QLabel *label_5;
    QLineEdit *lineEditStorageFileName;
    QPushButton *pushButtonBrowseStorageFileName;
    QGroupBox *groupBox_6;
    QVBoxLayout *verticalLayout_8;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_7;
    QLineEdit *lineEditBackupFolder;
    QPushButton *pushButtonBrowseBackupFolder;
    QHBoxLayout *horizontalLayout_10;
    QLabel *label;
    QComboBox *comboBoxBackupDelay;
    QGroupBox *groupBox_5;
    QVBoxLayout *verticalLayout_7;
    QHBoxLayout *horizontalLayout_8;
    QCheckBox *checkBoxClientMode;
    QLineEdit *lineEditClientModeHost;
    QGroupBox *groupBox;
    QVBoxLayout *verticalLayout_2;
    QCheckBox *checkBoxShowOSNotifications;
    QVBoxLayout *verticalLayout_3;
    QLabel *label_12;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *pushButtonSetNotificationWindow;
    QPushButton *pushButtonResetNotificationWindow;
    QHBoxLayout *horizontalLayout_9;
    QLabel *label_6;
    QSpinBox *spinBoxNotif_Delay;
    QHBoxLayout *horizontalLayout_11;
    QLabel *label_8;
    QSpinBox *spinBoxNotif_Opacity;
    QHBoxLayout *horizontalLayout_13;
    QLabel *label_10;
    QComboBox *comboBoxMouseBehavior;
    QHBoxLayout *horizontalLayout_14;
    QLabel *label_11;
    QComboBox *comboBoxCategorySelectionBehavior;
    QHBoxLayout *horizontalLayout_12;
    QLabel *label_13;
    QComboBox *comboBoxVisibilityBehavior;
    QCheckBox *checkBoxHideWIndowBorders;
    QLabel *label_9;
    QHBoxLayout *horizontalLayout_15;
    QLineEdit *lineEditNotif_Message;
    QPushButton *pushButton;
    QPushButton *pushButtonSetDefaultMessage;
    QCheckBox *checkBoxAutorun;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButtonApply;
    QPushButton *pushButtonCancel;
    QSpacerItem *verticalSpacer;

    void setupUi(QMainWindow *SettingsWindow)
    {
        if (SettingsWindow->objectName().isEmpty())
            SettingsWindow->setObjectName(QString::fromUtf8("SettingsWindow"));
        SettingsWindow->resize(578, 790);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(SettingsWindow->sizePolicy().hasHeightForWidth());
        SettingsWindow->setSizePolicy(sizePolicy);
        SettingsWindow->setMinimumSize(QSize(100, 100));
        SettingsWindow->setMaximumSize(QSize(2000, 2000));
        centralWidget = new QWidget(SettingsWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        verticalLayout = new QVBoxLayout(centralWidget);
        verticalLayout->setSpacing(3);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(3, 3, 3, 3);
        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        label_4 = new QLabel(centralWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setScaledContents(false);

        horizontalLayout_4->addWidget(label_4);

        comboBoxLanguage = new QComboBox(centralWidget);
        comboBoxLanguage->setObjectName(QString::fromUtf8("comboBoxLanguage"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(comboBoxLanguage->sizePolicy().hasHeightForWidth());
        comboBoxLanguage->setSizePolicy(sizePolicy1);

        horizontalLayout_4->addWidget(comboBoxLanguage);


        verticalLayout->addLayout(horizontalLayout_4);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setScaledContents(false);

        horizontalLayout_6->addWidget(label_2);

        spinBoxIdleDelay = new QSpinBox(centralWidget);
        spinBoxIdleDelay->setObjectName(QString::fromUtf8("spinBoxIdleDelay"));
        QSizePolicy sizePolicy2(QSizePolicy::Minimum, QSizePolicy::Preferred);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(spinBoxIdleDelay->sizePolicy().hasHeightForWidth());
        spinBoxIdleDelay->setSizePolicy(sizePolicy2);
        spinBoxIdleDelay->setMinimum(60);
        spinBoxIdleDelay->setMaximum(3600);
        spinBoxIdleDelay->setValue(300);

        horizontalLayout_6->addWidget(spinBoxIdleDelay);


        verticalLayout->addLayout(horizontalLayout_6);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setSpacing(6);
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        label_3 = new QLabel(centralWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setScaledContents(false);

        horizontalLayout_7->addWidget(label_3);

        spinBoxAutosaveDelay = new QSpinBox(centralWidget);
        spinBoxAutosaveDelay->setObjectName(QString::fromUtf8("spinBoxAutosaveDelay"));
        sizePolicy2.setHeightForWidth(spinBoxAutosaveDelay->sizePolicy().hasHeightForWidth());
        spinBoxAutosaveDelay->setSizePolicy(sizePolicy2);
        spinBoxAutosaveDelay->setMinimum(300);
        spinBoxAutosaveDelay->setMaximum(3600);
        spinBoxAutosaveDelay->setValue(1500);

        horizontalLayout_7->addWidget(spinBoxAutosaveDelay);


        verticalLayout->addLayout(horizontalLayout_7);

        groupBox_3 = new QGroupBox(centralWidget);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        verticalLayout_5 = new QVBoxLayout(groupBox_3);
        verticalLayout_5->setSpacing(0);
        verticalLayout_5->setContentsMargins(11, 11, 11, 11);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        verticalLayout_5->setContentsMargins(40, 0, 0, 0);
        groupBox_4 = new QGroupBox(groupBox_3);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        verticalLayout_6 = new QVBoxLayout(groupBox_4);
        verticalLayout_6->setSpacing(0);
        verticalLayout_6->setContentsMargins(11, 11, 11, 11);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        verticalLayout_6->setContentsMargins(40, 0, 0, 0);
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label_5 = new QLabel(groupBox_4);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        sizePolicy1.setHeightForWidth(label_5->sizePolicy().hasHeightForWidth());
        label_5->setSizePolicy(sizePolicy1);
        label_5->setScaledContents(false);

        horizontalLayout->addWidget(label_5);

        lineEditStorageFileName = new QLineEdit(groupBox_4);
        lineEditStorageFileName->setObjectName(QString::fromUtf8("lineEditStorageFileName"));
        QSizePolicy sizePolicy3(QSizePolicy::Expanding, QSizePolicy::Preferred);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(lineEditStorageFileName->sizePolicy().hasHeightForWidth());
        lineEditStorageFileName->setSizePolicy(sizePolicy3);

        horizontalLayout->addWidget(lineEditStorageFileName);

        pushButtonBrowseStorageFileName = new QPushButton(groupBox_4);
        pushButtonBrowseStorageFileName->setObjectName(QString::fromUtf8("pushButtonBrowseStorageFileName"));
        sizePolicy2.setHeightForWidth(pushButtonBrowseStorageFileName->sizePolicy().hasHeightForWidth());
        pushButtonBrowseStorageFileName->setSizePolicy(sizePolicy2);

        horizontalLayout->addWidget(pushButtonBrowseStorageFileName);


        verticalLayout_6->addLayout(horizontalLayout);

        groupBox_6 = new QGroupBox(groupBox_4);
        groupBox_6->setObjectName(QString::fromUtf8("groupBox_6"));
        verticalLayout_8 = new QVBoxLayout(groupBox_6);
        verticalLayout_8->setSpacing(0);
        verticalLayout_8->setContentsMargins(11, 11, 11, 11);
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        verticalLayout_8->setContentsMargins(40, 0, 0, 0);
        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        label_7 = new QLabel(groupBox_6);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        horizontalLayout_5->addWidget(label_7);

        lineEditBackupFolder = new QLineEdit(groupBox_6);
        lineEditBackupFolder->setObjectName(QString::fromUtf8("lineEditBackupFolder"));

        horizontalLayout_5->addWidget(lineEditBackupFolder);

        pushButtonBrowseBackupFolder = new QPushButton(groupBox_6);
        pushButtonBrowseBackupFolder->setObjectName(QString::fromUtf8("pushButtonBrowseBackupFolder"));

        horizontalLayout_5->addWidget(pushButtonBrowseBackupFolder);


        verticalLayout_8->addLayout(horizontalLayout_5);

        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setSpacing(6);
        horizontalLayout_10->setObjectName(QString::fromUtf8("horizontalLayout_10"));
        label = new QLabel(groupBox_6);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout_10->addWidget(label);

        comboBoxBackupDelay = new QComboBox(groupBox_6);
        comboBoxBackupDelay->addItem(QString());
        comboBoxBackupDelay->addItem(QString());
        comboBoxBackupDelay->addItem(QString());
        comboBoxBackupDelay->addItem(QString());
        comboBoxBackupDelay->addItem(QString());
        comboBoxBackupDelay->setObjectName(QString::fromUtf8("comboBoxBackupDelay"));

        horizontalLayout_10->addWidget(comboBoxBackupDelay);


        verticalLayout_8->addLayout(horizontalLayout_10);


        verticalLayout_6->addWidget(groupBox_6);


        verticalLayout_5->addWidget(groupBox_4);

        groupBox_5 = new QGroupBox(groupBox_3);
        groupBox_5->setObjectName(QString::fromUtf8("groupBox_5"));
        verticalLayout_7 = new QVBoxLayout(groupBox_5);
        verticalLayout_7->setSpacing(0);
        verticalLayout_7->setContentsMargins(11, 11, 11, 11);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        verticalLayout_7->setContentsMargins(40, 0, 0, 0);
        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setSpacing(6);
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        checkBoxClientMode = new QCheckBox(groupBox_5);
        checkBoxClientMode->setObjectName(QString::fromUtf8("checkBoxClientMode"));

        horizontalLayout_8->addWidget(checkBoxClientMode);

        lineEditClientModeHost = new QLineEdit(groupBox_5);
        lineEditClientModeHost->setObjectName(QString::fromUtf8("lineEditClientModeHost"));

        horizontalLayout_8->addWidget(lineEditClientModeHost);


        verticalLayout_7->addLayout(horizontalLayout_8);


        verticalLayout_5->addWidget(groupBox_5);


        verticalLayout->addWidget(groupBox_3);

        groupBox = new QGroupBox(centralWidget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        sizePolicy1.setHeightForWidth(groupBox->sizePolicy().hasHeightForWidth());
        groupBox->setSizePolicy(sizePolicy1);
        verticalLayout_2 = new QVBoxLayout(groupBox);
        verticalLayout_2->setSpacing(0);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        checkBoxShowOSNotifications = new QCheckBox(groupBox);
        checkBoxShowOSNotifications->setObjectName(QString::fromUtf8("checkBoxShowOSNotifications"));

        verticalLayout_2->addWidget(checkBoxShowOSNotifications);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setSpacing(0);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(40, -1, -1, 0);
        label_12 = new QLabel(groupBox);
        label_12->setObjectName(QString::fromUtf8("label_12"));

        verticalLayout_3->addWidget(label_12);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_2);

        pushButtonSetNotificationWindow = new QPushButton(groupBox);
        pushButtonSetNotificationWindow->setObjectName(QString::fromUtf8("pushButtonSetNotificationWindow"));

        horizontalLayout_3->addWidget(pushButtonSetNotificationWindow);

        pushButtonResetNotificationWindow = new QPushButton(groupBox);
        pushButtonResetNotificationWindow->setObjectName(QString::fromUtf8("pushButtonResetNotificationWindow"));

        horizontalLayout_3->addWidget(pushButtonResetNotificationWindow);


        verticalLayout_3->addLayout(horizontalLayout_3);

        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setSpacing(6);
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        label_6 = new QLabel(groupBox);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        horizontalLayout_9->addWidget(label_6);

        spinBoxNotif_Delay = new QSpinBox(groupBox);
        spinBoxNotif_Delay->setObjectName(QString::fromUtf8("spinBoxNotif_Delay"));
        spinBoxNotif_Delay->setMinimum(0);
        spinBoxNotif_Delay->setMaximum(60);
        spinBoxNotif_Delay->setValue(4);

        horizontalLayout_9->addWidget(spinBoxNotif_Delay);


        verticalLayout_3->addLayout(horizontalLayout_9);

        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setSpacing(6);
        horizontalLayout_11->setObjectName(QString::fromUtf8("horizontalLayout_11"));
        label_8 = new QLabel(groupBox);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        horizontalLayout_11->addWidget(label_8);

        spinBoxNotif_Opacity = new QSpinBox(groupBox);
        spinBoxNotif_Opacity->setObjectName(QString::fromUtf8("spinBoxNotif_Opacity"));
        spinBoxNotif_Opacity->setMinimum(1);
        spinBoxNotif_Opacity->setMaximum(100);
        spinBoxNotif_Opacity->setValue(100);

        horizontalLayout_11->addWidget(spinBoxNotif_Opacity);


        verticalLayout_3->addLayout(horizontalLayout_11);

        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setSpacing(6);
        horizontalLayout_13->setObjectName(QString::fromUtf8("horizontalLayout_13"));
        horizontalLayout_13->setContentsMargins(-1, 0, -1, -1);
        label_10 = new QLabel(groupBox);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        horizontalLayout_13->addWidget(label_10);

        comboBoxMouseBehavior = new QComboBox(groupBox);
        comboBoxMouseBehavior->addItem(QString());
        comboBoxMouseBehavior->addItem(QString());
        comboBoxMouseBehavior->addItem(QString());
        comboBoxMouseBehavior->addItem(QString());
        comboBoxMouseBehavior->setObjectName(QString::fromUtf8("comboBoxMouseBehavior"));

        horizontalLayout_13->addWidget(comboBoxMouseBehavior);


        verticalLayout_3->addLayout(horizontalLayout_13);

        horizontalLayout_14 = new QHBoxLayout();
        horizontalLayout_14->setSpacing(6);
        horizontalLayout_14->setObjectName(QString::fromUtf8("horizontalLayout_14"));
        horizontalLayout_14->setContentsMargins(-1, 0, -1, -1);
        label_11 = new QLabel(groupBox);
        label_11->setObjectName(QString::fromUtf8("label_11"));

        horizontalLayout_14->addWidget(label_11);

        comboBoxCategorySelectionBehavior = new QComboBox(groupBox);
        comboBoxCategorySelectionBehavior->addItem(QString());
        comboBoxCategorySelectionBehavior->addItem(QString());
        comboBoxCategorySelectionBehavior->addItem(QString());
        comboBoxCategorySelectionBehavior->setObjectName(QString::fromUtf8("comboBoxCategorySelectionBehavior"));

        horizontalLayout_14->addWidget(comboBoxCategorySelectionBehavior);


        verticalLayout_3->addLayout(horizontalLayout_14);

        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setSpacing(6);
        horizontalLayout_12->setObjectName(QString::fromUtf8("horizontalLayout_12"));
        horizontalLayout_12->setContentsMargins(-1, 0, -1, -1);
        label_13 = new QLabel(groupBox);
        label_13->setObjectName(QString::fromUtf8("label_13"));

        horizontalLayout_12->addWidget(label_13);

        comboBoxVisibilityBehavior = new QComboBox(groupBox);
        comboBoxVisibilityBehavior->addItem(QString());
        comboBoxVisibilityBehavior->addItem(QString());
        comboBoxVisibilityBehavior->addItem(QString());
        comboBoxVisibilityBehavior->addItem(QString());
        comboBoxVisibilityBehavior->setObjectName(QString::fromUtf8("comboBoxVisibilityBehavior"));

        horizontalLayout_12->addWidget(comboBoxVisibilityBehavior);


        verticalLayout_3->addLayout(horizontalLayout_12);

        checkBoxHideWIndowBorders = new QCheckBox(groupBox);
        checkBoxHideWIndowBorders->setObjectName(QString::fromUtf8("checkBoxHideWIndowBorders"));

        verticalLayout_3->addWidget(checkBoxHideWIndowBorders);

        label_9 = new QLabel(groupBox);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        verticalLayout_3->addWidget(label_9);

        horizontalLayout_15 = new QHBoxLayout();
        horizontalLayout_15->setSpacing(6);
        horizontalLayout_15->setObjectName(QString::fromUtf8("horizontalLayout_15"));
        horizontalLayout_15->setContentsMargins(-1, 0, -1, -1);
        lineEditNotif_Message = new QLineEdit(groupBox);
        lineEditNotif_Message->setObjectName(QString::fromUtf8("lineEditNotif_Message"));

        horizontalLayout_15->addWidget(lineEditNotif_Message);

        pushButton = new QPushButton(groupBox);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setMaximumSize(QSize(40, 16777215));

        horizontalLayout_15->addWidget(pushButton);

        pushButtonSetDefaultMessage = new QPushButton(groupBox);
        pushButtonSetDefaultMessage->setObjectName(QString::fromUtf8("pushButtonSetDefaultMessage"));

        horizontalLayout_15->addWidget(pushButtonSetDefaultMessage);


        verticalLayout_3->addLayout(horizontalLayout_15);


        verticalLayout_2->addLayout(verticalLayout_3);


        verticalLayout->addWidget(groupBox);

        checkBoxAutorun = new QCheckBox(centralWidget);
        checkBoxAutorun->setObjectName(QString::fromUtf8("checkBoxAutorun"));
        checkBoxAutorun->setEnabled(true);
        QSizePolicy sizePolicy4(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(checkBoxAutorun->sizePolicy().hasHeightForWidth());
        checkBoxAutorun->setSizePolicy(sizePolicy4);

        verticalLayout->addWidget(checkBoxAutorun);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        pushButtonApply = new QPushButton(centralWidget);
        pushButtonApply->setObjectName(QString::fromUtf8("pushButtonApply"));
        sizePolicy1.setHeightForWidth(pushButtonApply->sizePolicy().hasHeightForWidth());
        pushButtonApply->setSizePolicy(sizePolicy1);

        horizontalLayout_2->addWidget(pushButtonApply);

        pushButtonCancel = new QPushButton(centralWidget);
        pushButtonCancel->setObjectName(QString::fromUtf8("pushButtonCancel"));
        sizePolicy1.setHeightForWidth(pushButtonCancel->sizePolicy().hasHeightForWidth());
        pushButtonCancel->setSizePolicy(sizePolicy1);

        horizontalLayout_2->addWidget(pushButtonCancel);


        verticalLayout->addLayout(horizontalLayout_2);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        SettingsWindow->setCentralWidget(centralWidget);

        retranslateUi(SettingsWindow);

        QMetaObject::connectSlotsByName(SettingsWindow);
    } // setupUi

    void retranslateUi(QMainWindow *SettingsWindow)
    {
        SettingsWindow->setWindowTitle(QCoreApplication::translate("SettingsWindow", "Settings", nullptr));
        label_4->setText(QCoreApplication::translate("SettingsWindow", "Language(need restart):", nullptr));
        label_2->setText(QCoreApplication::translate("SettingsWindow", "Duration of inactivity before falling asleep(seconds):", nullptr));
        label_3->setText(QCoreApplication::translate("SettingsWindow", "Autosave: how often save db(seconds):", nullptr));
        groupBox_3->setTitle(QCoreApplication::translate("SettingsWindow", "Storage:", nullptr));
        groupBox_4->setTitle(QCoreApplication::translate("SettingsWindow", "Local storage:", nullptr));
        label_5->setText(QCoreApplication::translate("SettingsWindow", "DB file name:", nullptr));
        pushButtonBrowseStorageFileName->setText(QCoreApplication::translate("SettingsWindow", "Browse...", nullptr));
        groupBox_6->setTitle(QCoreApplication::translate("SettingsWindow", "Backup:", nullptr));
        label_7->setText(QCoreApplication::translate("SettingsWindow", "Backup folder:", nullptr));
        pushButtonBrowseBackupFolder->setText(QCoreApplication::translate("SettingsWindow", "Browse...", nullptr));
        label->setText(QCoreApplication::translate("SettingsWindow", "Backups delay between delete:", nullptr));
        comboBoxBackupDelay->setItemText(0, QCoreApplication::translate("SettingsWindow", "Day", nullptr));
        comboBoxBackupDelay->setItemText(1, QCoreApplication::translate("SettingsWindow", "Week", nullptr));
        comboBoxBackupDelay->setItemText(2, QCoreApplication::translate("SettingsWindow", "Month", nullptr));
        comboBoxBackupDelay->setItemText(3, QCoreApplication::translate("SettingsWindow", "Year", nullptr));
        comboBoxBackupDelay->setItemText(4, QCoreApplication::translate("SettingsWindow", "Forever", nullptr));

        groupBox_5->setTitle(QCoreApplication::translate("SettingsWindow", "Network storage:", nullptr));
        checkBoxClientMode->setText(QCoreApplication::translate("SettingsWindow", "Send data to another host:", nullptr));
        groupBox->setTitle(QCoreApplication::translate("SettingsWindow", "Notifications", nullptr));
        checkBoxShowOSNotifications->setText(QCoreApplication::translate("SettingsWindow", "Show OS notifications", nullptr));
        label_12->setText(QCoreApplication::translate("SettingsWindow", "Custom notification window settings", nullptr));
        pushButtonSetNotificationWindow->setText(QCoreApplication::translate("SettingsWindow", "Set window position and size", nullptr));
        pushButtonResetNotificationWindow->setText(QCoreApplication::translate("SettingsWindow", "Reset window position", nullptr));
        label_6->setText(QCoreApplication::translate("SettingsWindow", "Hide after(seconds)[0 - disable auto hiding]:", nullptr));
        label_8->setText(QCoreApplication::translate("SettingsWindow", "Opacity(percents)", nullptr));
        label_10->setText(QCoreApplication::translate("SettingsWindow", "Mouse behavior", nullptr));
        comboBoxMouseBehavior->setItemText(0, QCoreApplication::translate("SettingsWindow", "No actions", nullptr));
        comboBoxMouseBehavior->setItemText(1, QCoreApplication::translate("SettingsWindow", "Hide notification on mouse click", nullptr));
        comboBoxMouseBehavior->setItemText(2, QCoreApplication::translate("SettingsWindow", "Hide notification on mouse move", nullptr));
        comboBoxMouseBehavior->setItemText(3, QCoreApplication::translate("SettingsWindow", "Escape from mouse", nullptr));

        label_11->setText(QCoreApplication::translate("SettingsWindow", "Category selection behavior", nullptr));
        comboBoxCategorySelectionBehavior->setItemText(0, QCoreApplication::translate("SettingsWindow", "Always hide", nullptr));
        comboBoxCategorySelectionBehavior->setItemText(1, QCoreApplication::translate("SettingsWindow", "Always visible", nullptr));
        comboBoxCategorySelectionBehavior->setItemText(2, QCoreApplication::translate("SettingsWindow", "Visible if categoty not set for current activity", nullptr));

        label_13->setText(QCoreApplication::translate("SettingsWindow", "Visibility behavior", nullptr));
        comboBoxVisibilityBehavior->setItemText(0, QCoreApplication::translate("SettingsWindow", "Show on category changing", nullptr));
        comboBoxVisibilityBehavior->setItemText(1, QCoreApplication::translate("SettingsWindow", "Show on activity changing", nullptr));
        comboBoxVisibilityBehavior->setItemText(2, QCoreApplication::translate("SettingsWindow", "Show on any action", nullptr));
        comboBoxVisibilityBehavior->setItemText(3, QCoreApplication::translate("SettingsWindow", "Show only by menu", nullptr));

        checkBoxHideWIndowBorders->setText(QCoreApplication::translate("SettingsWindow", "Hide window borders and caption", nullptr));
        label_9->setText(QCoreApplication::translate("SettingsWindow", "Message format:", nullptr));
        pushButton->setText(QCoreApplication::translate("SettingsWindow", "?", nullptr));
        pushButtonSetDefaultMessage->setText(QCoreApplication::translate("SettingsWindow", "Set default message", nullptr));
        checkBoxAutorun->setText(QCoreApplication::translate("SettingsWindow", "Launch on Start up", nullptr));
        pushButtonApply->setText(QCoreApplication::translate("SettingsWindow", "Apply", nullptr));
        pushButtonCancel->setText(QCoreApplication::translate("SettingsWindow", "Cancel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class SettingsWindow: public Ui_SettingsWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SETTINGSWINDOW_H
