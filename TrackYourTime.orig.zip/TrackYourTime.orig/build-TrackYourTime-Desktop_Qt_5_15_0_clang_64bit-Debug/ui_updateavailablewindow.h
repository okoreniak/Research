/********************************************************************************
** Form generated from reading UI file 'updateavailablewindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_UPDATEAVAILABLEWINDOW_H
#define UI_UPDATEAVAILABLEWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_UpdateAvailableWindow
{
public:
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout_4;
    QSpacerItem *horizontalSpacer_3;
    QLabel *label_3;
    QLabel *labelCurrentVersion;
    QSpacerItem *horizontalSpacer_4;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer;
    QLabel *label;
    QLabel *labelNewVersion;
    QSpacerItem *horizontalSpacer_2;
    QHBoxLayout *horizontalLayout_3;
    QPushButton *pushButtonDownload;
    QPushButton *pushButtonChangelog;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *pushButtonIgnoreVersion;
    QPushButton *pushButtonRemindLater;

    void setupUi(QMainWindow *UpdateAvailableWindow)
    {
        if (UpdateAvailableWindow->objectName().isEmpty())
            UpdateAvailableWindow->setObjectName(QString::fromUtf8("UpdateAvailableWindow"));
        UpdateAvailableWindow->resize(800, 138);
        centralwidget = new QWidget(UpdateAvailableWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        verticalLayout = new QVBoxLayout(centralwidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_3);

        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_4->addWidget(label_3);

        labelCurrentVersion = new QLabel(centralwidget);
        labelCurrentVersion->setObjectName(QString::fromUtf8("labelCurrentVersion"));

        horizontalLayout_4->addWidget(labelCurrentVersion);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_4);


        verticalLayout->addLayout(horizontalLayout_4);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        labelNewVersion = new QLabel(centralwidget);
        labelNewVersion->setObjectName(QString::fromUtf8("labelNewVersion"));

        horizontalLayout->addWidget(labelNewVersion);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_2);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        pushButtonDownload = new QPushButton(centralwidget);
        pushButtonDownload->setObjectName(QString::fromUtf8("pushButtonDownload"));

        horizontalLayout_3->addWidget(pushButtonDownload);

        pushButtonChangelog = new QPushButton(centralwidget);
        pushButtonChangelog->setObjectName(QString::fromUtf8("pushButtonChangelog"));

        horizontalLayout_3->addWidget(pushButtonChangelog);


        verticalLayout->addLayout(horizontalLayout_3);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        pushButtonIgnoreVersion = new QPushButton(centralwidget);
        pushButtonIgnoreVersion->setObjectName(QString::fromUtf8("pushButtonIgnoreVersion"));

        horizontalLayout_2->addWidget(pushButtonIgnoreVersion);

        pushButtonRemindLater = new QPushButton(centralwidget);
        pushButtonRemindLater->setObjectName(QString::fromUtf8("pushButtonRemindLater"));

        horizontalLayout_2->addWidget(pushButtonRemindLater);


        verticalLayout->addLayout(horizontalLayout_2);

        UpdateAvailableWindow->setCentralWidget(centralwidget);

        retranslateUi(UpdateAvailableWindow);

        QMetaObject::connectSlotsByName(UpdateAvailableWindow);
    } // setupUi

    void retranslateUi(QMainWindow *UpdateAvailableWindow)
    {
        UpdateAvailableWindow->setWindowTitle(QCoreApplication::translate("UpdateAvailableWindow", "Update available", nullptr));
        label_3->setText(QCoreApplication::translate("UpdateAvailableWindow", "Current version:", nullptr));
        labelCurrentVersion->setText(QString());
        label->setText(QCoreApplication::translate("UpdateAvailableWindow", "New version available: ", nullptr));
        labelNewVersion->setText(QString());
        pushButtonDownload->setText(QCoreApplication::translate("UpdateAvailableWindow", "Download...", nullptr));
        pushButtonChangelog->setText(QCoreApplication::translate("UpdateAvailableWindow", "Changelog...", nullptr));
        pushButtonIgnoreVersion->setText(QCoreApplication::translate("UpdateAvailableWindow", "Skip this update", nullptr));
        pushButtonRemindLater->setText(QCoreApplication::translate("UpdateAvailableWindow", "Remind me later", nullptr));
    } // retranslateUi

};

namespace Ui {
    class UpdateAvailableWindow: public Ui_UpdateAvailableWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_UPDATEAVAILABLEWINDOW_H
